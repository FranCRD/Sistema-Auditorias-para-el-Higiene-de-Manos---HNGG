# Auditoría de Higiene de Manos — MySQL

Esta copia está preparada para PHP y MySQL (incluido Clever Cloud). La copia para SQL Server debe mantenerse separada.

## Configuración

La aplicación lee estas variables de entorno:

- `MYSQL_ADDON_HOST`
- `MYSQL_ADDON_PORT`
- `MYSQL_ADDON_USER`
- `MYSQL_ADDON_PASSWORD`
- `MYSQL_ADDON_DB`

En Clever Cloud, vincula el complemento MySQL a la aplicación para que sus variables estén disponibles en el entorno PHP. No guardes credenciales en los archivos del proyecto.

## Preparar la base de datos

Selecciona la base creada por el complemento y ejecuta [`Base de Datos/Sistema_Autorias_BD.sql`](Base%20de%20Datos/Sistema_Autorias_BD.sql). El script crea las tablas y vistas si aún no existen; no agrega usuarios de prueba ni contraseñas predeterminadas.

Para habilitar una cuenta de prueba como administradora:

1. Registra la cuenta desde `registro.html`.
2. En la base MySQL, aprueba y promueve únicamente esa cuenta:

   ```sql
   UPDATE Usuario
   SET Rol = 1, Estado = 1
   WHERE Correo = 'correo-de-prueba@example.com';
   ```

Las cuentas nuevas se crean como observadores pendientes (`Rol = 0`, `Estado = 0`).
