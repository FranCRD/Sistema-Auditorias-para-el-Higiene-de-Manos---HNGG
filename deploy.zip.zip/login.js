/* =========================================================
   LOGIN  Lgica del cliente
   ========================================================= */

/* =========================================================
   1. TOGGLE PASSWORD
   ========================================================= */
const pwdInput  = document.getElementById("password");
const pwdToggle = document.getElementById("toggle-password");

pwdToggle.addEventListener("click", () => {
  const show = pwdInput.type === "password";
  pwdInput.type = show ? "text" : "password";
  pwdToggle.querySelector(".material-symbols-outlined").textContent =
    show ? "visibility_off" : "visibility";
  pwdToggle.setAttribute("aria-label", show ? "Ocultar contraseña" : "Mostrar contraseña");
});

/* =========================================================
   2. UTILIDADES
   ========================================================= */
function showMessage(el, text, type = "info") {
  el.textContent = text;
  el.className = `form__message is-visible is-${type}`;
}
function hideMessage(el) {
  el.className = "form__message";
}
function setLoading(btn, loading) {
  btn.disabled = loading;
  btn.classList.toggle("is-loading", loading);
}

/* =========================================================
   3. SUBMIT LOGIN
   ========================================================= */
const loginForm    = document.getElementById("login-form");
const loginMessage = document.getElementById("login-message");
const loginSubmit  = document.getElementById("login-submit");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideMessage(loginMessage);

  const credential = document.getElementById("credential").value.trim();
  const password   = pwdInput.value;

  // Validación básica en el cliente
  if (!credential || !password) {
    document.getElementById("credential").classList.toggle("is-invalid", !credential);
    pwdInput.classList.toggle("is-invalid", !password);
    showMessage(loginMessage, "Complete todos los campos obligatorios.", "error");
    return;
  }

  setLoading(loginSubmit, true);

  try {
    // Enviar al backend
    const formData = new FormData();
    formData.append("credential", credential);
    formData.append("password", password);

    const response = await fetch("validar_Login.php", {
      method: "POST",
      body: formData
    });

    if (!response.ok) {
      showMessage(loginMessage, `Error del servidor (HTTP ${response.status}).`, "error");
      setLoading(loginSubmit, false);
      return;
    }

    const data = await response.json();

    if (!data.ok) {
      showMessage(loginMessage, data.message || "Error al iniciar sesión.", "error");
      setLoading(loginSubmit, false);
      return;
    }

    //  Login exitoso
    showMessage(loginMessage, "Acceso concedido. Redirigiendo…", "success");

    // Guardar info del usuario en sessionStorage (para uso del frontend)
    sessionStorage.setItem("hm_user", JSON.stringify(data.usuario));

    // Redirigir según el rol
    setTimeout(() => {
      if (data.usuario.Rol === 1) {
        window.location.href = "admin.php";   // Admin
      } else {
        window.location.href = "index.html";   // Usuario normal
      }
    }, 700);

  } catch (err) {
    showMessage(loginMessage, "Error de conexión con el servidor.", "error");
    console.error(err);
    setLoading(loginSubmit, false);
  }
});

/* =========================================================
   4. RECUPERACIÓN (por ahora solo visual)
   ========================================================= */
const viewLogin    = document.getElementById("view-login");
const viewRecovery = document.getElementById("view-recovery");

document.getElementById("goto-recovery").addEventListener("click", () => {
  viewLogin.classList.add("is-hidden");
  viewRecovery.classList.remove("is-hidden");
  document.getElementById("recovery-email").focus();
});

document.getElementById("back-to-login").addEventListener("click", () => {
  viewRecovery.classList.add("is-hidden");
  viewLogin.classList.remove("is-hidden");
  hideMessage(document.getElementById("recovery-message"));
  document.getElementById("credential").focus();
});

const recoveryForm    = document.getElementById("recovery-form");
const recoveryMessage = document.getElementById("recovery-message");
const recoverySubmit  = document.getElementById("recovery-submit");

recoveryForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideMessage(recoveryMessage);
  setLoading(recoverySubmit, true);
  await new Promise((r) => setTimeout(r, 800));
  setLoading(recoverySubmit, false);
  showMessage(
    recoveryMessage,
    "Si el correo está registrado, recibirá un enlace en los próximos minutos.",
    "success"
  );
  recoveryForm.reset();
});

/* =========================================================
   5. LIMPIAR ESTADO
   ========================================================= */
document.getElementById("credential").addEventListener("input", (e) =>
  e.target.classList.remove("is-invalid")
);
pwdInput.addEventListener("input", (e) =>
  e.target.classList.remove("is-invalid")
);