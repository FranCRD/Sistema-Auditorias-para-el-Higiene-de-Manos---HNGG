/* =========================================================
   0. GUARDIA DE SESIÓN
   ========================================================= */
(function guardSession() {
  const session = sessionStorage.getItem("hm_user");
  if (!session) {
    window.location.replace("login.html");
  }
})();

/* =========================================================
   1. ETIQUETAS DE LOS MOMENTOS
   ========================================================= */
const MOMENTS_LABELS = {
  1: { short: "M1", name: "Antes del contacto" },
  2: { short: "M2", name: "Antes de tarea aséptica" },
  3: { short: "M3", name: "Post-fluidos" },
  4: { short: "M4", name: "Post-paciente" },
  5: { short: "M5", name: "Post-entorno" }
};

const TAB_A_CATEGORIA = {
  doctors: "Medicina",
  nurses:  "Enfermería",
  techs:   "Otros"
};

/* =========================================================
   2. DATOS GLOBALES
   ========================================================= */
let DATOS = null;
let TAB_ACTIVA = "doctors";

/* =========================================================
   3. UTILIDADES
   ========================================================= */
function rowTotal(row) {
  return (row?.lavado || 0) + (row?.alcohol || 0) + (row?.noRealiza || 0);
}

function columnTotals(data) {
  const totals = { lavado: 0, alcohol: 0, noRealiza: 0 };
  for (let m = 1; m <= 5; m++) {
    const row = data[m] || { lavado: 0, alcohol: 0, noRealiza: 0 };
    totals.lavado    += row.lavado;
    totals.alcohol   += row.alcohol;
    totals.noRealiza += row.noRealiza;
  }
  totals.total = totals.lavado + totals.alcohol + totals.noRealiza;
  return totals;
}

function pct(value, total) {
  if (!total) return "0%";
  return `${((value / total) * 100).toFixed(0)}%`;
}

/* =========================================================
   4. RENDER DE KPIs
   ========================================================= */
function renderKPIs() {
  const { kpis } = DATOS;

  const kpi1 = document.querySelector(".kpi--success");
  if (kpi1) {
    const numero = kpi1.querySelector(".kpi__number");
    const hint   = kpi1.querySelector(".kpi__hint");
    const bar    = kpi1.querySelector(".kpi__bar-fill");
    if (numero) numero.textContent = kpis.cumplimiento.toFixed(1);
    if (hint)   hint.textContent = `${kpis.cumplidas} de ${kpis.totalAcciones} acciones`;
    if (bar)    bar.style.width = `${kpis.cumplimiento}%`;
  }

  const kpi2 = document.querySelector(".kpi--error");
  if (kpi2) {
    const numero = kpi2.querySelector(".kpi__number");
    const hint   = kpi2.querySelector(".kpi__hint");
    const bar    = kpi2.querySelector(".kpi__bar-fill");
    if (numero) numero.textContent = kpis.noRealizado.toFixed(1);
    if (hint)   hint.textContent = `${kpis.omitidas} oportunidades omitidas`;
    if (bar)    bar.style.width = `${kpis.noRealizado}%`;
  }

  const kpi3 = document.querySelector(".kpi--warning");
  if (kpi3) {
    const numero = kpi3.querySelector(".kpi__number");
    const hints  = kpi3.querySelectorAll(".kpi__hint");
    if (kpis.momentoCritico.id) {
      const label = MOMENTS_LABELS[kpis.momentoCritico.id];
      if (numero) numero.textContent = label ? label.short : `M${kpis.momentoCritico.id}`;
      if (hints[0]) hints[0].textContent = `${label ? label.name : ""} · ${kpis.momentoCritico.casos} casos`;
    } else {
      if (numero) numero.textContent = "—";
      if (hints[0]) hints[0].textContent = "Sin datos suficientes";
    }
  }
}

/* =========================================================
   5. RENDER DEL GRÁFICO DE MOMENTOS
   ========================================================= */
function renderChart() {
  const container = document.getElementById("chart-moments");
  if (!container) return;

  const porMomento = DATOS.porMomento;

  let max = 0;
  for (let m = 1; m <= 5; m++) {
    const row = porMomento[m] || { lavado: 0, alcohol: 0, noRealiza: 0 };
    max = Math.max(max, row.lavado, row.alcohol, row.noRealiza);
  }
  max = max || 1;

  const groupsHTML = [1, 2, 3, 4, 5]
    .map((m) => {
      const row   = porMomento[m] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      const hWash    = (row.lavado    / max) * 100;
      const hAlcohol = (row.alcohol   / max) * 100;
      const hMiss    = (row.noRealiza / max) * 100;
      const label    = MOMENTS_LABELS[m];

      const bar = (value, height, type) => `
        <div class="chart__bar chart__bar--${type}" style="height: ${height}%">
          ${value ? `<span class="chart__bar-value">${value}</span>` : ""}
        </div>
      `;

      return `
        <div class="chart__group">
          <div class="chart__bars">
            ${bar(row.lavado,    hWash,    "wash")}
            ${bar(row.alcohol,   hAlcohol, "alcohol")}
            ${bar(row.noRealiza, hMiss,    "miss")}
          </div>
          <div class="chart__label">
            ${label.short}
            <span>${label.name}</span>
          </div>
        </div>
      `;
    })
    .join("");

  container.innerHTML = groupsHTML;
}

/* =========================================================
   6. TABLA CONSOLIDADA
   ========================================================= */
function renderMomentsTable() {
  const tbody = document.getElementById("table-moments");
  const tfoot = document.getElementById("table-moments-footer");
  const chip  = document.getElementById("table-total-chip");
  if (!tbody || !tfoot) return;

  const porMomento = DATOS.porMomento;

  tbody.innerHTML = [1, 2, 3, 4, 5]
    .map((m) => {
      const row = porMomento[m] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      const label = MOMENTS_LABELS[m];
      return `
        <tr>
          <td>
            <span class="momento-badge">
              <span class="momento-badge__num">${m}</span>
              ${label.name}
            </span>
          </td>
          <td class="table__num table__num--wash">${row.lavado}</td>
          <td class="table__num table__num--alcohol">${row.alcohol}</td>
          <td class="table__num table__num--miss">${row.noRealiza}</td>
          <td class="table__num table__num--total">${rowTotal(row)}</td>
        </tr>
      `;
    })
    .join("");

  const t = columnTotals(porMomento);
  tfoot.innerHTML = `
    <tr>
      <td>Total</td>
      <td class="table__num table__num--wash">${t.lavado}</td>
      <td class="table__num table__num--alcohol">${t.alcohol}</td>
      <td class="table__num table__num--miss">${t.noRealiza}</td>
      <td class="table__num table__num--total">${t.total}</td>
    </tr>
    <tr>
      <td>Porcentaje</td>
      <td class="table__num">${pct(t.lavado, t.total)}</td>
      <td class="table__num">${pct(t.alcohol, t.total)}</td>
      <td class="table__num">${pct(t.noRealiza, t.total)}</td>
      <td class="table__num">${t.total ? "100%" : "0%"}</td>
    </tr>
  `;

  if (chip) chip.textContent = `Total: ${t.total} obs.`;
}

/* =========================================================
   7. SELECTOR DE SUBCATEGORÍA
   ========================================================= */
function poblarSubcategorias(tabKey) {
  const select = document.getElementById("subcat-select");
  if (!select) return;

  const categoria = TAB_A_CATEGORIA[tabKey] || "Medicina";
  const catData   = DATOS.porCategoria[categoria];
  const subcats   = DATOS.catalogoSubcats[categoria] || [];

  let html = `<option value="__all__">Todas las subcategorías</option>`;

  subcats.forEach((sub) => {
    const dataSub = catData?.subcategorias?.[sub]?.consolidado || {};
    const total = columnTotals(dataSub).total;
    html += `<option value="${sub}">${sub} (${total})</option>`;
  });

  const dataSin = catData?.subcategorias?.["__sin__"]?.consolidado || {};
  const totalSin = columnTotals(dataSin).total;
  html += `<option value="__sin__">(Sin especificar) (${totalSin})</option>`;

  select.innerHTML = html;
  select.value = "__all__";
}

/* =========================================================
   8. TABLA POR CATEGORÍA (con filtro de subcategoría)
   ========================================================= */
function renderCategoryTable(tabKey, subcatValue = "__all__") {
  const tbody = document.getElementById("table-category");
  const tfoot = document.getElementById("table-category-footer");
  if (!tbody || !tfoot) return;

  const categoria = TAB_A_CATEGORIA[tabKey] || "Medicina";
  const catData   = DATOS.porCategoria[categoria];

  let data = {};
  if (subcatValue === "__all__") {
    data = catData?.consolidado || {};
  } else {
    data = catData?.subcategorias?.[subcatValue]?.consolidado || {};
  }

  tbody.innerHTML = [1, 2, 3, 4, 5]
    .map((m) => {
      const row = data[m] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      const label = MOMENTS_LABELS[m];
      return `
        <tr>
          <td>
            <span class="momento-badge">
              <span class="momento-badge__num">${m}</span>
              ${label.name}
            </span>
          </td>
          <td class="table__num table__num--wash">${row.lavado}</td>
          <td class="table__num table__num--alcohol">${row.alcohol}</td>
          <td class="table__num table__num--miss">${row.noRealiza}</td>
          <td class="table__num table__num--total">${rowTotal(row)}</td>
        </tr>
      `;
    })
    .join("");

  const t = columnTotals(data);
  tfoot.innerHTML = `
    <tr>
      <td>Total</td>
      <td class="table__num table__num--wash">${t.lavado}</td>
      <td class="table__num table__num--alcohol">${t.alcohol}</td>
      <td class="table__num table__num--miss">${t.noRealiza}</td>
      <td class="table__num table__num--total">${t.total}</td>
    </tr>
  `;
}

function renderCategoryPrintTables() {
  const container = document.getElementById("print-category-tables");
  if (!container) return;

  container.innerHTML = Object.entries(DATOS.porCategoria || {}).map(([category, categoryData]) => {
    const data = categoryData?.consolidado || {};
    const rows = [1, 2, 3, 4, 5].map((moment) => {
      const row = data[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      return `
        <tr>
          <td>${moment}. ${MOMENTS_LABELS[moment].name}</td>
          <td class="table__num table__num--wash">${row.lavado}</td>
          <td class="table__num table__num--alcohol">${row.alcohol}</td>
          <td class="table__num table__num--miss">${row.noRealiza}</td>
          <td class="table__num table__num--total">${rowTotal(row)}</td>
        </tr>
      `;
    }).join("");
    const totals = columnTotals(data);

    return `
      <section class="print-category-table">
        <h3 class="print-category-table__title">${category}</h3>
        <div class="table-wrap">
          <table class="table">
            <thead>
              <tr>
                <th>Momento</th>
                <th class="ta-c">Lavado</th>
                <th class="ta-c">Solución de alcohol</th>
                <th class="ta-c">No lo realiza</th>
                <th class="ta-c">Total</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
            <tfoot>
              <tr>
                <td>Total</td>
                <td class="table__num table__num--wash">${totals.lavado}</td>
                <td class="table__num table__num--alcohol">${totals.alcohol}</td>
                <td class="table__num table__num--miss">${totals.noRealiza}</td>
                <td class="table__num table__num--total">${totals.total}</td>
              </tr>
              <tr>
                <td>Porcentaje</td>
                <td class="table__num">${pct(totals.lavado, totals.total)}</td>
                <td class="table__num">${pct(totals.alcohol, totals.total)}</td>
                <td class="table__num">${pct(totals.noRealiza, totals.total)}</td>
                <td class="table__num">${totals.total ? "100%" : "0%"}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </section>
    `;
  }).join("");
}

/* =========================================================
   9. TABS + SUBCATEGORÍAS
   ========================================================= */
function setupTabs() {
  const tabs = document.querySelectorAll(".tab[data-tab]");
  const select = document.getElementById("subcat-select");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("is-active"));
      tab.classList.add("is-active");

      TAB_ACTIVA = tab.dataset.tab;
      poblarSubcategorias(TAB_ACTIVA);
      renderCategoryTable(TAB_ACTIVA, "__all__");
    });
  });

  if (select) {
    select.addEventListener("change", () => {
      renderCategoryTable(TAB_ACTIVA, select.value);
    });
  }
}

/* =========================================================
   10. EXPORTAR PDF
   ========================================================= */
function setupExportPDF() {
  const btn = document.getElementById("export-pdf");
  if (!btn) return;
  btn.addEventListener("click", () => window.print());
}

/* =========================================================
   10.1 EXPORTAR EXCEL — Formato IAAS HNGG con ExcelJS
   ========================================================= */
function setupExportExcel() {
  const btn = document.getElementById("export-excel");
  if (!btn) return;

  btn.addEventListener("click", async () => {
    if (!DATOS) {
      alert("Aún no hay datos cargados. Espere un momento e intente de nuevo.");
      return;
    }

    if (typeof ExcelJS === "undefined") {
      alert("No se pudo cargar la librería de Excel. Recargue la página e intente de nuevo.");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      workbook.creator = "Sistema de Auditoría de Higiene de Manos - HNGG";
      workbook.created = new Date();

      const areas = DATOS.areas || [];

      areas.forEach((area) => {
        const hojaNombre = area.substring(0, 31);
        const ws = workbook.addWorksheet(hojaNombre, {
          views: [{ showGridLines: false, zoomScale: 60 }],
          pageSetup: {
            paperSize: 9,
            orientation: "landscape",
            fitToPage: true,
            fitToWidth: 1,
            fitToHeight: 0,
            margins: { left: 0.5, right: 0.5, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 }
          }
        });

        ws.columns = Array.from({ length: 30 }, () => ({ width: 10.9 }));
        [26.1, 22.8, 33.7, 24.7, 30.9].forEach((width, index) => {
          ws.getColumn(index + 2).width = width;
        });
        [14.9, 14, 26.6, 17.4, 21.6].forEach((width, index) => {
          ws.getColumn(index + 8).width = width;
        });
        ws.getColumn(15).width = 23.1;
        [16, 17, 18, 19, 20].forEach((column) => { ws.getColumn(column).width = 10.9; });
        ws.getColumn(21).width = 10.9;
        ws.getColumn(22).width = 16.1;
        [23, 24, 25, 26, 27, 28].forEach((column) => { ws.getColumn(column).width = 10.9; });
        ws.getColumn(29).width = 13.9;
        ws.getColumn(30).width = 13.5;

        construirHojaArea(ws, area);
      });

      if (areas.length === 0) {
        const ws = workbook.addWorksheet("Sin datos");
        ws.getCell("A1").value = "No hay observaciones registradas.";
      }

      // Descargar
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const fecha = new Date().toISOString().split("T")[0];
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Evaluacion_Estrategia_Multimodal_Higiene_Manos_${fecha}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);

    } catch (err) {
      console.error("Error al exportar Excel:", err);
      alert("Error al generar el archivo Excel: " + err.message);
    }
  });
}

/* =========================================================
   CONSTRUIR UNA HOJA POR ÁREA CON FORMATO IAAS
   ========================================================= */
function validarDatosAreaParaExcel(data, area) {
  const acciones = ["lavado", "alcohol", "noRealiza"];
  const totales = { lavado: 0, alcohol: 0, noRealiza: 0 };

  for (let moment = 1; moment <= 5; moment++) {
    const observaciones = data.porMomento[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
    const sumaCategorias = { lavado: 0, alcohol: 0, noRealiza: 0 };

    ["Medicina", "Enfermería", "Otros"].forEach((category) => {
      const row = data.porCategoria[category]?.[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      acciones.forEach((accion) => { sumaCategorias[accion] += row[accion]; });
    });

    acciones.forEach((accion) => {
      if (sumaCategorias[accion] !== observaciones[accion]) {
        throw new Error(`Los datos de ${area}, momento M${moment}, no coinciden entre el total y las categorías.`);
      }
      totales[accion] += observaciones[accion];
    });
  }

  acciones.forEach((accion) => {
    if (totales[accion] !== data[`total${accion[0].toUpperCase()}${accion.slice(1)}`]) {
      throw new Error(`El total de ${accion} en ${area} no coincide con el detalle por momento.`);
    }
  });
}

function construirHojaArea(ws, area) {
  const data = DATOS.porArea[area] || {
    porMomento: {}, porCategoria: {}, totalLavado: 0, totalAlcohol: 0, totalNoRealiza: 0
  };
  validarDatosAreaParaExcel(data, area);
  const font = { name: "Times New Roman", size: 14, color: { argb: "FF0B1C30" } };
  const border = {
    top: { style: "thin", color: { argb: "FF9AAFC2" } },
    bottom: { style: "thin", color: { argb: "FF9AAFC2" } },
    left: { style: "thin", color: { argb: "FF9AAFC2" } },
    right: { style: "thin", color: { argb: "FF9AAFC2" } }
  };
  const titleStyle = {
    font: { ...font, bold: true, color: { argb: "FFFFFFFF" } },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FF00507D" } },
    alignment: { horizontal: "center", vertical: "middle", wrapText: true }, border
  };
  const subtitleStyle = {
    font: { ...font, italic: true, color: { argb: "FF40474F" } },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FFEFF4FF" } },
    alignment: { horizontal: "left", vertical: "middle", wrapText: true }, border
  };
  const headerStyle = {
    font: { ...font, bold: true },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FFCDE5FF" } },
    alignment: { horizontal: "center", vertical: "middle", wrapText: true }, border
  };
  const textStyle = {
    font, alignment: { horizontal: "left", vertical: "middle", wrapText: true }, border
  };
  const numberStyle = {
    font, alignment: { horizontal: "center", vertical: "middle" }, border, numFmt: "0"
  };
  const totalStyle = {
    ...numberStyle,
    font: { ...font, bold: true },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFF2CC" } },
    border: {
      ...border,
      top: { style: "medium", color: { argb: "FF00507D" } },
      bottom: { style: "medium", color: { argb: "FF00507D" } }
    }
  };
  const percentageStyle = {
    ...numberStyle,
    font: { ...font, bold: true, color: { argb: "FF00573A" } },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FFD1FAE5" } },
    numFmt: "0%"
  };
  const sourceStyle = {
    font: { ...font, italic: true, size: 11, color: { argb: "FF707881" } },
    alignment: { horizontal: "left", vertical: "middle" }
  };
  const mergeTitle = (row, firstCol, lastCol, value, style) => {
    ws.mergeCells(row, firstCol, row, lastCol);
    for (let col = firstCol; col <= lastCol; col++) ws.getCell(row, col).style = style;
    ws.getCell(row, firstCol).value = value;
    ws.getRow(row).height = style === titleStyle ? 24 : 18;
  };
  const setRow = (row, firstCol, values, style) => {
    values.forEach((value, offset) => {
      const cell = ws.getCell(row, firstCol + offset);
      const cellStyle = typeof style === "function" ? style(offset, cell) : style;
      cell.value = value;
      cell.style = JSON.parse(JSON.stringify(cellStyle));
    });
  };
  const percentage = (value, total) => total > 0 ? value / total : 0;

  const totalCumplidas = data.totalLavado + data.totalAlcohol;
  const totalGeneral = totalCumplidas + data.totalNoRealiza;
  mergeTitle(2, 2, 4, `Cuadro 3. Total de Observaciones en ${area} por N\u00famero y Porcentaje del Cumplimiento`, titleStyle);
  mergeTitle(3, 2, 4, "de la Estrategia de Higiene Multimodal durante Evaluaci\u00f3n", subtitleStyle);
  setRow(4, 2, ["Actividad", "N\u00famero de observaciones", "Porcentaje"], headerStyle);
  ws.getRow(4).height = 31;
  setRow(5, 2, ["Higiene de las manos", totalCumplidas, percentage(totalCumplidas, totalGeneral)],
    (offset) => offset === 0 ? textStyle : offset === 1 ? numberStyle : percentageStyle);
  setRow(6, 2, ["No lo realiza", data.totalNoRealiza, percentage(data.totalNoRealiza, totalGeneral)],
    (offset) => offset === 0 ? textStyle : offset === 1 ? numberStyle : percentageStyle);
  setRow(7, 2, ["Total", totalGeneral, percentage(totalGeneral, totalGeneral)],
    (offset) => offset === 0
      ? { ...totalStyle, alignment: { horizontal: "left", vertical: "middle" } }
      : offset === 1 ? totalStyle : percentageStyle);
  ws.getCell("B8").value = "Fuente: Comit\u00e9 de IAAS HNGG";
  ws.getCell("B8").style = sourceStyle;

  mergeTitle(12, 2, 6, `Cuadro 3. N\u00famero de Observaciones en ${area}, por momento de higiene y acci\u00f3n`, titleStyle);
  mergeTitle(13, 2, 6, "realizada durante Evaluaci\u00f3n de Estrategia Multimodal", subtitleStyle);
  setRow(14, 2, ["Momento", "Lavado", "Soluci\u00f3n de Alcohol", "No lo realiza", "Total"], headerStyle);
  ws.getRow(14).height = 27;
  let washTotal = 0, alcoholTotal = 0, missTotal = 0;
  for (let moment = 1; moment <= 5; moment++) {
    const values = data.porMomento[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
    setRow(14 + moment, 2, [moment, values.lavado, values.alcohol, values.noRealiza,
      values.lavado + values.alcohol + values.noRealiza], numberStyle);
    washTotal += values.lavado;
    alcoholTotal += values.alcohol;
    missTotal += values.noRealiza;
  }
  const momentTotal = washTotal + alcoholTotal + missTotal;
  setRow(20, 2, ["Total", washTotal, alcoholTotal, missTotal, momentTotal],
    (offset) => offset === 0 ? { ...totalStyle, alignment: { horizontal: "left", vertical: "middle" } } : totalStyle);
  setRow(21, 2, ["Porcentaje", percentage(washTotal, momentTotal), percentage(alcoholTotal, momentTotal),
    percentage(missTotal, momentTotal), percentage(momentTotal, momentTotal)], percentageStyle);
  ws.getCell("B22").value = "Fuente: Comit\u00e9 de IAAS HNGG";
  ws.getCell("B22").style = sourceStyle;

  const categories = [
    { key: "Medicina", title: "Observaciones en personal m\u00e9dico por momento de higiene y acci\u00f3n realizada", startRow: 2 },
    { key: "Enfermer\u00eda", title: "Observaciones en personal de enfermer\u00eda por momento de higiene y acci\u00f3n realizada", startRow: 16 },
    { key: "Otros", title: "Observaciones en terapeutas, t\u00e9cnicos y otros por momento de higiene y acci\u00f3n realizada", startRow: 31 }
  ];
  categories.forEach(({ key, title, startRow }) => {
    const headerRow = startRow + 2;
    const dataStartRow = headerRow + 1;
    const dataCat = data.porCategoria[key] || {};
    mergeTitle(startRow, 8, 12, title, titleStyle);
    mergeTitle(startRow + 1, 8, 12, "realizada durante Evaluaci\u00f3n de Estrategia Multimodal", subtitleStyle);
    setRow(headerRow, 8, ["Momento", "Lavado", "Soluci\u00f3n de Alcohol", "No lo realiza", "Total"], headerStyle);
    ws.getRow(headerRow).height = 27;
    let categoryWash = 0, categoryAlcohol = 0, categoryMiss = 0;
    for (let moment = 1; moment <= 5; moment++) {
      const values = dataCat[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      setRow(dataStartRow + moment - 1, 8, [moment, values.lavado, values.alcohol, values.noRealiza,
        values.lavado + values.alcohol + values.noRealiza], numberStyle);
      categoryWash += values.lavado;
      categoryAlcohol += values.alcohol;
      categoryMiss += values.noRealiza;
    }
    const totalRow = dataStartRow + 5;
    const percentageRow = totalRow + 1;
    const categoryTotal = categoryWash + categoryAlcohol + categoryMiss;
    setRow(totalRow, 8, ["Total", categoryWash, categoryAlcohol, categoryMiss, categoryTotal],
      (offset) => offset === 0 ? { ...totalStyle, alignment: { horizontal: "left", vertical: "middle" } } : totalStyle);
    setRow(percentageRow, 8, ["Porcentaje", percentage(categoryWash, categoryTotal),
      percentage(categoryAlcohol, categoryTotal), percentage(categoryMiss, categoryTotal),
      percentage(categoryTotal, categoryTotal)], percentageStyle);
    ws.getCell(percentageRow + 1, 8).value = "Fuente: Comit\u00e9 de IAAS HNGG";
    ws.getCell(percentageRow + 1, 8).style = sourceStyle;
  });

  mergeTitle(2, 15, 30, `N\u00famero de observaciones por momento de higiene y acci\u00f3n realizada durante Evaluaci\u00f3n de Estrategia Multimodal \u2014 ${area}`, titleStyle);
  setRow(3, 15, ["Acciones"], headerStyle);
  ["Medicina", "Enfermer\u00eda", "Otros"].forEach((category, index) => {
    const firstCol = 16 + index * 5;
    ws.mergeCells(3, firstCol, 3, firstCol + 4);
    for (let col = firstCol; col <= firstCol + 4; col++) ws.getCell(3, col).style = headerStyle;
    ws.getCell(3, firstCol).value = category;
  });
  setRow(4, 15, ["Momento de higiene de manos", ...Array(3).fill([1, 2, 3, 4, 5]).flat()], headerStyle);
  ws.getRow(4).height = 27;
  const actions = [
    { key: "lavado", label: "Lavado" },
    { key: "alcohol", label: "Soluci\u00f3n alcoh\u00f3lica" },
    { key: "noRealiza", label: "No realiza" }
  ];
  actions.forEach(({ key, label }, actionIndex) => {
    const values = [label];
    categories.forEach(({ key: categoryKey }) => {
      for (let moment = 1; moment <= 5; moment++) {
        const momentData = data.porCategoria[categoryKey]?.[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
        values.push(momentData[key]);
      }
    });
    setRow(5 + actionIndex, 15, values, (offset) => offset === 0 ? textStyle : numberStyle);
  });
  const matrixTotals = ["Total"];
  categories.forEach(({ key }) => {
    for (let moment = 1; moment <= 5; moment++) {
      const values = data.porCategoria[key]?.[moment] || { lavado: 0, alcohol: 0, noRealiza: 0 };
      matrixTotals.push(values.lavado + values.alcohol + values.noRealiza);
    }
  });
  setRow(8, 15, matrixTotals, totalStyle);
  ws.getCell("O9").value = "Fuente: Comit\u00e9 de IAAS HNGG";
  ws.getCell("O9").style = sourceStyle;
  ws.getRow(3).height = 18;
  ws.getRow(32).height = 18;
  ws.pageSetup.printArea = "B2:AD41";
}

/* =========================================================
   11. CARGA DE DATOS
   ========================================================= */
async function cargarDashboard() {
  try {
    const response = await fetch("datos_dashboard.php");
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.message || "No se pudieron cargar los datos del dashboard.");
    }

    DATOS = data;
    const loadError = document.getElementById("dashboard-load-error");
    if (loadError) {
      loadError.hidden = true;
      loadError.textContent = "";
    }

    if (DATOS.totalObservaciones === 0) {
      const main = document.querySelector("main.container");
      if (main) {
        main.insertAdjacentHTML("afterbegin", `
          <div class="empty-state" style="margin-bottom:1rem;">
            <span class="material-symbols-outlined">analytics</span>
            <p>Aún no hay observaciones registradas. Los gráficos se llenarán cuando existan sesiones completadas.</p>
          </div>
        `);
      }
    }

    renderKPIs();
    renderChart();
    renderMomentsTable();

    TAB_ACTIVA = "doctors";
    poblarSubcategorias(TAB_ACTIVA);
    renderCategoryTable(TAB_ACTIVA, "__all__");
    renderCategoryPrintTables();
    setupTabs();

    console.log("Dashboard cargado con datos reales:", DATOS);

  } catch (err) {
    console.error("Error al cargar dashboard:", err);

    const loadError = document.getElementById("dashboard-load-error");
    if (loadError) {
      const detail = err.message === "No autorizado"
        ? "La sesión del servidor expiró; cierre sesión y vuelva a ingresar"
        : `Error: ${err.message}`;
      loadError.textContent = `No se pudieron cargar los reportes. ${detail}.`;
      loadError.hidden = false;
    }
  }
}

/* =========================================================
   12. INICIALIZACIÓN
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  if (window.SKIP_DASHBOARD_INIT) return;

  const session = JSON.parse(sessionStorage.getItem("hm_user") || "{}");
  const userNameEl = document.getElementById("user-name");
  if (userNameEl && session.Nombre) {
    userNameEl.textContent = session.Nombre;
  }

  const adminLink = document.getElementById("admin-link");
  if (adminLink) {
    fetch("sesion_actual.php")
      .then((response) => {
        if (!response.ok) throw new Error(`No se pudo validar la sesión (${response.status}).`);
        return response.json();
      })
      .then((data) => {
        if (data.ok && data.usuario.Rol === 1) {
          adminLink.hidden = false;
        }
      })
      .catch((err) => console.error("Error al validar permisos:", err));
  }

  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", async () => {
      if (await confirmarAccion({
        titulo: "¿Cerrar sesión?",
        mensaje: "Se cerrará tu sesión actual.",
        confirmar: "Cerrar sesión"
      })) {
        sessionStorage.removeItem("hm_user");
        window.location.href = "cerrar_sesion.php";
      }
    });
  }

  setupExportPDF();
  setupExportExcel();
  cargarDashboard();
});