<?php
/* =========================================================
   RECHAZAR USUARIO (eliminar solicitud pendiente)
   ========================================================= */
session_start();
header('Content-Type: application/json; charset=utf-8');

include("conexion.php");

if (!isset($_SESSION['Rol']) || $_SESSION['Rol'] != 1) {
    echo json_encode(['ok' => false, 'message' => 'No autorizado']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['ok' => false, 'message' => 'ID inválido']);
    exit;
}

$sql    = "DELETE FROM Usuario WHERE ID_usuario = ? AND Estado = 0";
$params = [$id];
$stmt   = db_query($conexion, $sql, $params);

if ($stmt === false) {
    echo json_encode([
        'ok'      => false,
        'message' => 'Error al rechazar',
    ]);
    exit;
}

$rows = mysqli_stmt_affected_rows($stmt);

if ($rows > 0) {
    echo json_encode(['ok' => true, 'message' => 'Solicitud rechazada.']);
} else {
    echo json_encode(['ok' => false, 'message' => 'No se pudo rechazar la solicitud.']);
}

db_free_stmt($stmt);
mysqli_close($conexion);
?>