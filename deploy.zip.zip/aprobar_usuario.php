<?php
/* =========================================================
   APROBAR USUARIO (Estado 0 → 1)
   ========================================================= */
session_start();
header('Content-Type: application/json; charset=utf-8');

include("conexion.php");

if (!isset($_SESSION['Rol']) || $_SESSION['Rol'] != 1) {
    echo json_encode(['ok' => false, 'message' => 'No autorizado']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['ok' => false, 'message' => 'ID inválido']);
    exit;
}

$sql    = "UPDATE Usuario SET Estado = 1 WHERE ID_usuario = ?";
$params = [$id];
$stmt   = db_query($conexion, $sql, $params);

if ($stmt === false) {
    echo json_encode([
        'ok'      => false,
        'message' => 'Error al aprobar',
    ]);
    exit;
}

$rows = mysqli_stmt_affected_rows($stmt);

if ($rows > 0) {
    echo json_encode(['ok' => true, 'message' => 'Usuario aprobado correctamente.']);
} else {
    echo json_encode(['ok' => false, 'message' => 'No se pudo aprobar el usuario.']);
}

db_free_stmt($stmt);
mysqli_close($conexion);
?>