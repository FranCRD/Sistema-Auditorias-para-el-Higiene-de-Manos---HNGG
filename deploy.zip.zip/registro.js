/* =========================================================
   REGISTRO — Lógica del cliente
   ========================================================= */

/* =========================================================
   1. TOGGLE PASSWORD
   ========================================================= */
const pwdInput  = document.getElementById("password");
const pwdToggle = document.getElementById("toggle-password");

if (pwdToggle) {
  pwdToggle.addEventListener("click", () => {
    const show = pwdInput.type === "password";
    pwdInput.type = show ? "text" : "password";
    pwdToggle.querySelector(".material-symbols-outlined").textContent =
      show ? "visibility_off" : "visibility";
  });
}

/* =========================================================
   2. UTILIDADES
   ========================================================= */
function showMessage(el, text, type = "info") {
  el.textContent = text;
  el.className = `form__message is-visible is-${type}`;
}
function hideMessage(el) {
  el.className = "form__message";
}
function setLoading(btn, loading) {
  btn.disabled = loading;
  btn.classList.toggle("is-loading", loading);
}

/* =========================================================
   3. SUBMIT REGISTRO
   ========================================================= */
const registerForm    = document.getElementById("register-form");
const registerMessage = document.getElementById("register-message");
const registerSubmit  = document.getElementById("register-submit");

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideMessage(registerMessage);

  const nombre      = document.getElementById("full-name").value.trim();
  const cedula      = document.getElementById("cedula").value.trim();
  const correo      = document.getElementById("email").value.trim();
  const password    = pwdInput.value;
  const password2   = document.getElementById("password-confirm").value;
  const aceptaTerms = document.getElementById("terms").checked;

  // Validaciones en el cliente
  if (!nombre || !cedula || !correo || !password || !password2) {
    showMessage(registerMessage, "Complete todos los campos obligatorios.", "error");
    return;
  }
  if (cedula.length > 30) {
    showMessage(registerMessage, "La cédula o identificación no puede superar 30 caracteres.", "error");
    return;
  }
  if (password.length < 8) {
    showMessage(registerMessage, "La contraseña debe tener al menos 8 caracteres.", "error");
    return;
  }
  if (password !== password2) {
    showMessage(registerMessage, "Las contraseñas no coinciden.", "error");
    return;
  }
  if (!aceptaTerms) {
    showMessage(registerMessage, "Debe aceptar el uso de datos institucionales.", "error");
    return;
  }

  setLoading(registerSubmit, true);

  try {
    const formData = new FormData();
    formData.append("full-name", nombre);
    formData.append("cedula", cedula);
    formData.append("email", correo);
    formData.append("password", password);
    formData.append("password-confirm", password2);

    const response = await fetch("validar_registro.php", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (!data.ok) {
      showMessage(registerMessage, data.message || "Error al registrarse.", "error");
      setLoading(registerSubmit, false);
      return;
    }

    //  Registro exitoso
    showMessage(registerMessage, "Solicitud enviada. Redirigiendo al inicio de sesión…", "success");

    setTimeout(() => {
      window.location.href = "login.html";
    }, 2000);

  } catch (err) {
    showMessage(registerMessage, "Error de conexión con el servidor.", "error");
    console.error(err);
    setLoading(registerSubmit, false);
  }
});