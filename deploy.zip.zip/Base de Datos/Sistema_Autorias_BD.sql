-- MySQL 8 schema for the Clever Cloud database.
-- Select the database created by the MySQL add-on before running this file.

CREATE TABLE IF NOT EXISTS Usuario (
    ID_usuario INT NOT NULL AUTO_INCREMENT,
    Nombre VARCHAR(80) NOT NULL,
    Apellidos VARCHAR(120) NOT NULL,
    Cedula VARCHAR(30) NOT NULL,
    Correo VARCHAR(150) NOT NULL,
    Contrasena VARCHAR(255) NOT NULL,
    Rol TINYINT UNSIGNED NOT NULL DEFAULT 0,
    Estado TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (ID_usuario),
    UNIQUE KEY UQ_Usuario_Cedula (Cedula),
    UNIQUE KEY UQ_Usuario_Correo (Correo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS SesionObservacion (
    ID_sesion INT NOT NULL AUTO_INCREMENT,
    Fecha DATE NOT NULL,
    HoraInicio TIME NOT NULL,
    HoraFin TIME NOT NULL,
    Duracion SMALLINT GENERATED ALWAYS AS (
        TIME_TO_SEC(TIMEDIFF(HoraFin, HoraInicio)) DIV 60
    ) STORED,
    NumeroSesion INT NOT NULL,
    DepartamentoServicio VARCHAR(100) NOT NULL,
    NombreSala VARCHAR(100) NULL,
    ID_usuario INT NOT NULL,
    Estado VARCHAR(20) NOT NULL DEFAULT 'active',
    PRIMARY KEY (ID_sesion),
    KEY IX_SesionObservacion_Usuario_Estado (ID_usuario, Estado),
    CONSTRAINT FK_Sesion_Usuario FOREIGN KEY (ID_usuario)
        REFERENCES Usuario(ID_usuario),
    CONSTRAINT CK_Sesion_Departamento CHECK (
        DepartamentoServicio IN ('I Este', 'II Este', 'I Oeste', 'II Oeste', 'UCI')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS EvaluacionProfesional (
    ID_evaluacion INT NOT NULL AUTO_INCREMENT,
    CategoriaProfesional VARCHAR(60) NOT NULL,
    SubcategoriaProfesional VARCHAR(60) NULL,
    CodigoProfesional VARCHAR(40) NOT NULL,
    NumeroProfesional INT NOT NULL,
    ID_sesion INT NOT NULL,
    Notas VARCHAR(500) NULL,
    PRIMARY KEY (ID_evaluacion),
    KEY IX_EvaluacionProfesional_Sesion (ID_sesion),
    CONSTRAINT FK_Evaluacion_Sesion FOREIGN KEY (ID_sesion)
        REFERENCES SesionObservacion(ID_sesion) ON DELETE CASCADE,
    CONSTRAINT CK_Evaluacion_Categoria CHECK (
        CategoriaProfesional IN ('Medicina', 'Enfermería', 'Otros')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS MomentoHigiene (
    ID_momento INT NOT NULL AUTO_INCREMENT,
    Tipo_momento INT NOT NULL,
    Accion_Realizada VARCHAR(40) NULL,
    ID_evaluacion INT NOT NULL,
    PRIMARY KEY (ID_momento),
    UNIQUE KEY UQ_Momento_UnicoPorEvaluacion (ID_evaluacion, Tipo_momento),
    CONSTRAINT FK_Momento_Evaluacion FOREIGN KEY (ID_evaluacion)
        REFERENCES EvaluacionProfesional(ID_evaluacion) ON DELETE CASCADE,
    CONSTRAINT CK_Momento_Tipo CHECK (Tipo_momento BETWEEN 1 AND 5),
    CONSTRAINT CK_Momento_Accion CHECK (
        Accion_Realizada IS NULL OR Accion_Realizada IN ('Lavado', 'Alcohol', 'No realizado')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE OR REPLACE VIEW vw_CumplimientoPorSesion AS
SELECT
    so.ID_sesion,
    so.Fecha,
    so.DepartamentoServicio,
    so.NombreSala,
    CONCAT(u.Nombre, ' ', u.Apellidos) AS Observador,
    COUNT(mh.ID_momento) AS TotalObservaciones,
    SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END) AS Cumplidas,
    SUM(CASE WHEN mh.Accion_Realizada = 'No realizado' THEN 1 ELSE 0 END) AS Omitidas,
    CAST(100.0 * SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END)
         / NULLIF(COUNT(mh.ID_momento), 0) AS DECIMAL(5,2)) AS PorcentajeCumplimiento
FROM SesionObservacion so
JOIN Usuario u ON u.ID_usuario = so.ID_usuario
LEFT JOIN EvaluacionProfesional ep ON ep.ID_sesion = so.ID_sesion
LEFT JOIN MomentoHigiene mh ON mh.ID_evaluacion = ep.ID_evaluacion
GROUP BY so.ID_sesion, so.Fecha, so.DepartamentoServicio, so.NombreSala, u.Nombre, u.Apellidos;

CREATE OR REPLACE VIEW vw_MatrizMomentoCategoria AS
SELECT
    so.DepartamentoServicio,
    ep.CategoriaProfesional,
    ep.SubcategoriaProfesional,
    mh.Tipo_momento,
    mh.Accion_Realizada,
    COUNT(*) AS Cantidad
FROM MomentoHigiene mh
JOIN EvaluacionProfesional ep ON ep.ID_evaluacion = mh.ID_evaluacion
JOIN SesionObservacion so ON so.ID_sesion = ep.ID_sesion
GROUP BY so.DepartamentoServicio, ep.CategoriaProfesional, ep.SubcategoriaProfesional,
         mh.Tipo_momento, mh.Accion_Realizada;

CREATE OR REPLACE VIEW vw_CumplimientoPorDepartamento AS
SELECT
    so.DepartamentoServicio,
    COUNT(mh.ID_momento) AS TotalObservaciones,
    SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END) AS Cumplidas,
    SUM(CASE WHEN mh.Accion_Realizada = 'No realizado' THEN 1 ELSE 0 END) AS Omitidas,
    CAST(100.0 * SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END)
         / NULLIF(COUNT(mh.ID_momento), 0) AS DECIMAL(5,2)) AS PorcentajeCumplimiento
FROM SesionObservacion so
LEFT JOIN EvaluacionProfesional ep ON ep.ID_sesion = so.ID_sesion
LEFT JOIN MomentoHigiene mh ON mh.ID_evaluacion = ep.ID_evaluacion
GROUP BY so.DepartamentoServicio;

CREATE OR REPLACE VIEW vw_CumplimientoPorCategoria AS
SELECT
    ep.CategoriaProfesional,
    ep.SubcategoriaProfesional,
    COUNT(mh.ID_momento) AS TotalObservaciones,
    SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END) AS Cumplidas,
    SUM(CASE WHEN mh.Accion_Realizada = 'No realizado' THEN 1 ELSE 0 END) AS Omitidas,
    CAST(100.0 * SUM(CASE WHEN mh.Accion_Realizada IN ('Lavado', 'Alcohol') THEN 1 ELSE 0 END)
         / NULLIF(COUNT(mh.ID_momento), 0) AS DECIMAL(5,2)) AS PorcentajeCumplimiento
FROM EvaluacionProfesional ep
LEFT JOIN MomentoHigiene mh ON mh.ID_evaluacion = ep.ID_evaluacion
GROUP BY ep.CategoriaProfesional, ep.SubcategoriaProfesional;

-- To promote the account created through registro.html for a test deployment:
-- UPDATE Usuario SET Rol = 1, Estado = 1 WHERE Correo = 'admin@example.com';